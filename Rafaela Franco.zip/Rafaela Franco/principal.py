
def limparTela():
   