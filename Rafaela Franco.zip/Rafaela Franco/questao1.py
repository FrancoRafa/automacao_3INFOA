'''Crie um programa para auxiliar os cozinheiros a converter a unidade de 
medida copo em mililitros. O programa deve solicitar como entrada a 
quantidade de copos; em seguida, deve imprimir a quantidade 
correspondente em mililitros, multiplicando a quantidade de copos por 
200.
'''
quantidade = input("Digite a quantidade de copos: ")
valor = int(quantidade) * 200
print("A quantidade correspondente em mililitros é:", valor)



